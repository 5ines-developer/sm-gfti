<?php 

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'mail.5ine.in';
$config['smtp_port'] = 587;
$config['smtp_user'] = 'testing@5ine.in';
$config['smtp_pass'] = '5ine%ine1234';
$config['mailtype'] = 'html';
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;


